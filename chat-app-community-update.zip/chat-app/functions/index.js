const express = require('express');
const cors = require('cors');
const { onRequest } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore, Timestamp, FieldValue } = require('firebase-admin/firestore');
const {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} = require('@simplewebauthn/server');

initializeApp();
const db = getFirestore();
const app = express();
app.use(cors({ origin: true }));
app.use(express.json({ limit: '1mb' }));
const RP_ID = process.env.PASSKEY_RP_ID || 'localhost';
const RP_NAME = process.env.PASSKEY_RP_NAME || 'Chat App';
const ORIGIN = process.env.PASSKEY_ORIGIN || 'http://localhost:5000';
const b64 = (buf) => Buffer.from(buf).toString('base64url');
const unb64 = (str) => Buffer.from(str, 'base64url');
const newSession = async (data) => {
  const ref = db.collection('passkeySessions').doc();
  await ref.set({ ...data, expiresAt: Timestamp.fromDate(new Date(Date.now() + 5 * 60 * 1000)) });
  return ref.id;
};
async function signedIn(req) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) throw new Error('Sign in is required.');
  const decoded = await getAuth().verifyIdToken(h.slice(7));
  if (decoded.email_verified !== true) throw new Error('Verify your email before continuing.');
  return decoded;
}
function requireConfig() {
  if (!process.env.PASSKEY_ORIGIN || !process.env.PASSKEY_RP_ID) {
    throw new Error('Passkey server is not configured. Set PASSKEY_ORIGIN and PASSKEY_RP_ID.');
  }
}

app.post('/register/options', async (req, res) => {
  try {
    requireConfig();
    const user = await signedIn(req);
    const record = await getAuth().getUser(user.uid);
    const existing = await db.collection('passkeys').where('uid', '==', user.uid).get();
    const options = await generateRegistrationOptions({
      rpName: RP_NAME,
      rpID: RP_ID,
      userID: Buffer.from(user.uid),
      userName: record.email || user.uid,
      userDisplayName: record.displayName || record.email || 'Chat App user',
      attestationType: 'none',
      excludeCredentials: existing.docs.map((d) => ({ id: d.data().credentialId, transports: d.data().transports || [] })),
      authenticatorSelection: { residentKey: 'preferred', userVerification: 'preferred' },
    });
    const sessionId = await newSession({ type: 'register', uid: user.uid, challenge: options.challenge });
    res.json({ options, sessionId });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.post('/register/verify', async (req, res) => {
  try {
    requireConfig();
    const user = await signedIn(req);
    const { sessionId, response } = req.body;
    const ref = db.collection('passkeySessions').doc(sessionId);
    const snap = await ref.get();
    if (!snap.exists || snap.data().type !== 'register' || snap.data().uid !== user.uid || snap.data().expiresAt.toDate() < new Date()) throw new Error('Registration session expired. Try again.');
    const verification = await verifyRegistrationResponse({ response, expectedChallenge: snap.data().challenge, expectedOrigin: ORIGIN, expectedRPID: RP_ID, requireUserVerification: false });
    if (!verification.verified || !verification.registrationInfo) throw new Error('Passkey registration could not be verified.');
    const c = verification.registrationInfo.credential;
    await db.collection('passkeys').doc(c.id).set({ credentialId: c.id, uid: user.uid, publicKey: b64(c.publicKey), counter: c.counter, transports: c.transports || [], createdAt: Timestamp.now() });
    const record = await getAuth().getUser(user.uid);
    if (record.email) await db.collection('passkeyUsers').doc(record.email.toLowerCase()).set({ uid: user.uid });
    await ref.delete();
    res.json({ verified: true });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.post('/auth/options', async (req, res) => {
  try {
    requireConfig();
    const email = String(req.body.email || '').trim().toLowerCase();
    if (!email) throw new Error('Enter your email address.');
    const userMap = await db.collection('passkeyUsers').doc(email).get();
    if (!userMap.exists) throw new Error('No passkey is registered for this email.');
    const uid = userMap.data().uid;
    const creds = await db.collection('passkeys').where('uid', '==', uid).get();
    if (creds.empty) throw new Error('No passkey is registered for this account.');
    const options = await generateAuthenticationOptions({
      rpID: RP_ID,
      allowCredentials: creds.docs.map((d) => ({ id: d.data().credentialId, transports: d.data().transports || [] })),
      userVerification: 'preferred',
    });
    const sessionId = await newSession({ type: 'auth', uid, challenge: options.challenge });
    res.json({ options, sessionId });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.post('/auth/verify', async (req, res) => {
  try {
    requireConfig();
    const { sessionId, response } = req.body;
    const sessionRef = db.collection('passkeySessions').doc(sessionId);
    const session = await sessionRef.get();
    if (!session.exists || session.data().type !== 'auth' || session.data().expiresAt.toDate() < new Date()) throw new Error('Sign-in session expired. Try again.');
    const credentialId = response.rawId;
    const credentialRef = db.collection('passkeys').doc(credentialId);
    const credentialSnap = await credentialRef.get();
    if (!credentialSnap.exists || credentialSnap.data().uid !== session.data().uid) throw new Error('Passkey not recognized.');
    const saved = credentialSnap.data();
    const verification = await verifyAuthenticationResponse({
      response,
      expectedChallenge: session.data().challenge,
      expectedOrigin: ORIGIN,
      expectedRPID: RP_ID,
      credential: { id: saved.credentialId, publicKey: unb64(saved.publicKey), counter: saved.counter, transports: saved.transports || [] },
      requireUserVerification: false,
    });
    if (!verification.verified) throw new Error('Passkey sign-in could not be verified.');
    await credentialRef.update({ counter: verification.authenticationInfo.newCounter, lastUsedAt: Timestamp.now() });
    await sessionRef.delete();
    const customToken = await getAuth().createCustomToken(session.data().uid);
    res.json({ customToken });
  } catch (e) { res.status(400).json({ error: e.message }); }
});


app.post('/invites/join', async (req, res) => {
  try {
    const user = await signedIn(req);
    const code = String(req.body.code || '').trim().toUpperCase();
    if (!/^[A-HJ-NP-Z2-9]{8}$/.test(code)) throw new Error('Invite code is invalid.');
    const invite = await db.collection('invites').doc(code).get();
    if (!invite.exists) throw new Error('Invite link not found.');
    const data = invite.data();
    if (!data.expiresAt || data.expiresAt.toDate() < new Date()) throw new Error('This invite has expired.');
    const serverRef = db.collection('servers').doc(data.serverId);
    const server = await serverRef.get();
    if (!server.exists) throw new Error('That server no longer exists.');
    await serverRef.update({ members: FieldValue.arrayUnion(user.uid) });
    for (const collectionName of ['messages', 'polls']) {
      let cursor = null;
      while (true) {
        let query = db.collection(collectionName).where('serverId', '==', data.serverId).orderBy('__name__').limit(400);
        if (cursor) query = query.startAfter(cursor);
        const page = await query.get();
        if (page.empty) break;
        const batch = db.batch();
        page.docs.forEach((doc) => batch.update(doc.ref, { memberUids: FieldValue.arrayUnion(user.uid) }));
        await batch.commit();
        cursor = page.docs[page.docs.length - 1];
        if (page.size < 400) break;
      }
    }
    res.json({ serverId: data.serverId });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

exports.passkeys = onRequest({ region: 'us-central1', cors: true }, app);
